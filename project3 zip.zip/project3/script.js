window.onload = function(){
    alert("Welcome to Nanthitha's Portfolio!");
};

const themeBtn = document.getElementById("themeBtn");

themeBtn.addEventListener("click", function(){
    document.body.classList.toggle("dark");
});

const skillBtn = document.getElementById("skillBtn");
const skillList = document.getElementById("skillList");

skillBtn.addEventListener("click", function(){
    if(skillList.style.display === "none"){
        skillList.style.display = "flex";
    } else {
        skillList.style.display = "none";
    }
});

function showMessage(){
    alert("Thank you for visiting my portfolio!");
}

document.getElementById("contactForm").addEventListener("submit", function(e){
    e.preventDefault();
    alert("Message Sent Successfully!");
});